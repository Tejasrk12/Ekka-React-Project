import React from 'react'

export default function HeaderWishlist() {
  return (
    <>
    <div className="header-icon"><i className="fi-rr-heart"></i></div>
    <span className="ec-header-count">4</span>
    </>
  )
}

 
